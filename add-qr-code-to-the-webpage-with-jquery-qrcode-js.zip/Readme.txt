Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/add-qr-code-to-the-webpage-with-jquery-qrcode-js/
